<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Interview Questions</title>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>        
    <link rel="stylesheet" href="https://unpkg.com/dropzone/dist/dropzone.css" />
    <link href="https://unpkg.com/cropperjs/dist/cropper.css" rel="stylesheet"/>
    <script src="https://kit.fontawesome.com/64d58efce2.js" crossorigin="anonymous"></script>
    <script src="https://unpkg.com/dropzone"></script>
    <script src="https://unpkg.com/cropperjs"></script>
    <link rel="stylesheet" href="designs.css">
    <?php include "slidepanel/slide.php" ?>
    <link rel="stylesheet" href="slidepanel/slidebar.css">
    <script type="text/javascript" src="slidepanel/slidepanels.js"></script>
</head>

<body> 
    <div id="main">
     <!--image upload code/image change-->
    <div class="container" align="center">
        <br />
        <h3 align="center">Edit Profile</h3>
        <br />
        <div class="row">
            <div class="col-md-4">&nbsp;</div>
            <div class="col-md-4">
                <div class="image_area">
                    <form method="post">
                        <label for="upload_image">
                            <img src="upload/user.png" id="uploaded_image" class="img-responsive img-circle" />
                            <div class="overlay">
                                <div class="text"><i class="fas fa-camera-retro"></i><br />Profile Image</div>
                            </div>
                            <input type="file" name="image" class="image" id="upload_image" style="display:none" />
                        </label>
                    </form>
                </div>
            </div>
        <div class="modal fade" id="modal" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true">
              <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title">Crop Image Before Upload</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">×</span>
                        </button>
                      </div>
                      <div class="modal-body">
                        <div class="img-container">
                            <div class="row">
                                <div class="col-md-8">
                                    <img src="" id="sample_image" />
                                </div>
                                <div class="col-md-4">
                                    <div class="preview"></div>
                                </div>
                            </div>
                        </div>
                      </div>
                      <div class="modal-footer">
                          <button type="button" id="crop" class="btn btn-primary">Crop</button>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                      </div>
                </div>
              </div>
        </div>	
        
        
    </div>
    <!---Taking information and updating it--->
    <div>
        <h4>Information</h4>
     <div class="cont">
        <div class="input-field">
               <i class="fas fa-user"></i>  
               <input type="text" id="name" name="name" placeholder="Enter Name" required/>
         </div>
        <div class="input-field">
            <i class="fas fa-envelope"></i>
            <input type="email" id="mail" name="mail" placeholder="Enter Email" required/>
        </div>
        <div class="input-field">
            <i class="fas fa-user"></i>
            <input type="number" id="number" name="number" placeholder="Enter Mobile Number" required/>
        </div>
        <div class="input-fieldOccu">
            <i class="fas fa-user"></i>
            <select name="Occupation" id="Occupation" required>
                <option value="Occupation">Occupatient</option>
                <option value="Programmer">Programmer</option>
                <option value="Doctor">Doctor</option>
                <option value="Bank Manager">Bank Manager</option>
                <option value="Teacher">Teacher</option>
            </select>      
        </div>
        <div class="input-fieldtext">
            Address:<textarea name="address" id="address" rows="5" cols="40"></textarea>
        </div>
        <div class="radiobtn">
            <input type="radio" id="gender" name="gender" value="female">Female
            <input type="radio" id="gender" name="gender" value="Male">Male
            <input type="radio" id="gender" name="gender" value="others">Others
        </div>
        <div class="custom-control custom-switch">
           <input type="checkbox" class="custom-control-input" id="customSwitch1">
           <label class="custom-control-label" for="customSwitch1">Toggle this switch element</label>
        </div>
        <br />
        <div>
            <input type="submit" class="btn" name="submit" id="Update" value="Update" onclick="myFunction()"/>
        </div>

     </div>
        
      

    </div>
    </div>
</body>
</html>

<script>

$(document).ready(function(){

var $modal = $('#modal');

var image = document.getElementById('sample_image');

var cropper;

$('#upload_image').change(function(event){
    var files = event.target.files;

    var done = function(url){
        image.src = url;
        $modal.modal('show');
    };

    if(files && files.length > 0)
    {
        reader = new FileReader();
        reader.onload = function(event)
        {
            done(reader.result);
        };
        reader.readAsDataURL(files[0]);
    }
});

$modal.on('shown.bs.modal', function() {
    cropper = new Cropper(image, {
        aspectRatio: 1,
        viewMode: 3,
        preview:'.preview'
    });
}).on('hidden.bs.modal', function(){
    cropper.destroy();
       cropper = null;
});

$('#crop').click(function(){
    canvas = cropper.getCroppedCanvas({
        width:400,
        height:400
    });

    canvas.toBlob(function(blob){
        url = URL.createObjectURL(blob);
        var reader = new FileReader();
        reader.readAsDataURL(blob);
        reader.onloadend = function(){
            var base64data = reader.result;
            $.ajax({
                url:'uploads.php',
                method:'POST',
                data:{image:base64data},
                success:function(data)
                {
                    $modal.modal('hide');
                    $('#uploaded_image').attr('src', data);
                }
            });
        };
    });
});

});


function myFunction() {
  var txt;
  if (confirm("Updated!")) {
    txt = "You pressed Yes!";
  } else {
    txt = "You pressed No!";
  }
  document.getElementById("Interview").innerHTML = txt;
}

</script>