<!DOCTYPE html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
</head>

<body>
    <div class="menu">

    </div>

    <div id="mySidebar" class="sidebar" onmouseover="toggleSidebar()" onmouseout="toggleSidebar()">
        <a href="datatable.php"><span><i class="material-icons">face</i><span class="icon-text">&nbsp;&nbsp;&nbsp;&nbsp;Display Users </span></a><br>
        <a href="index.php"><span><i class="material-icons">face</i><span class="icon-text">&nbsp;&nbsp;&nbsp;&nbsp;Edit Profile</span></a><br>
    </div>


</body>

</html>
